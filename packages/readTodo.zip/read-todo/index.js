const AWS = require("aws-sdk");
const DynamoDB = new AWS.DynamoDB.DocumentClient();

exports.handler = async function (event, context, callback) {
    console.log(event);
    let resultStatus;
    try {
      const params = {
        TableName: "todo-table",
        Key:{
            "pk": event.queryStringParameters.id
        }
    };
    
    // Call DynamoDB to read the item from the table
    resultStatus = await DynamoDB.get(params).promise()
    .then(function(data) {
        return data.Item;
      })
      .catch(function(err) {
        console.log({ err });
        return 400;
      });
    } catch(err) {
      resultStatus=400;
    }

    callback(null, {
        statusCode: resultStatus === 400 ? 400 : 200,
        body: JSON.stringify({
          response: resultStatus
        })
  });
  
};
