// TODO: Add code for reading todos

exports.handler = function (event, context) {
  return "Create todo";
};
